Extract "cohra.dat" to the same folder as "cohra.exe".

COHRA will automatically load "cohra.dat" upon startup.