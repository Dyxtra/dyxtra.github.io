
CREATING YOUR OWN EXTERNAL DATA LISTS FOR COH REPLAY ANALYZER
============================================================================================
Sander Dijkstra, may 2009


Starting with version 0.9, COH Replay Analyzer supports loading of external IDs for units,
buildings, upgrades, unit commands, command tree choices and special abilities.

This way, users can fix any mistakes I made or add IDs I forgot themselves.

If you have made any useful lists and want me to add them to my site, you can e-mail
them to me (address can be found in COH Replay Analyzer > About).



USAGE
============================================================================================
COHRA looks for the file "cohra.dat" in the folder where cohra.exe is located, and parses
it automatically if found.

If the version auto-detection fails, you can force a certain ID list via
Options > Override ID data.



COHRA.DAT STRUCTURE
============================================================================================
COHRA parses the cohra.dat file on a line-by-line basis. A line is made out of 6 parameters:

	8,0,UNITCOMMAND,"This is an example",0xa1,0
	
--- Parameter #1 is the patch version.
	COHRA 0.9 uses the following internal numbering:

		0 = 1.0-1.2
		1 = 1.3-1.5
		2 = 1.6-1.7.1
		3 = 2.101
		4 = 2.102-2.103
		5 = 2.200-2.201
		6 = 2.300-2.301
		7 = 2.400
		8 = 2.5+
		
	So if you want to fix or add and ID for an existing patch, use the corresponding number:

		6,0,UNITCOMMAND,"This is an example",0xa1,0
	
	If you want to add support for a COH version not yet in COHRA, use a string with the
	version name:
	
		2.701,0,UNITCOMMAND,"This is an example",0xa1,0
		
	The version will show up in COHRA as you entered it above.
	

--- Parameter #2 is the game type:
		0 = Classic multiplayer
		1 = Stonewall
		2 = Panzerkrieg
		3 = Assault
	
	
--- Parameter #3 is the object type, valid types are:
		UNIT - Any units that are produced (not called in off-map).
		BUILDING - Any buildings or defenses you can construct, including Flak, Howitzer etc.
		COMMANDTREE - Choices made in the company commander menu.
		UPGRADE - Any global or unit-specific upgrades.
		SPECIALABILITY - Special abilities unlocked by a COMMANDTREE command, like firing a V1 rocket.
		UNITCOMMAND - Commands available when a unit is selected, like throwing a grenade or activating camouflage.

		
--- Parameter #4 is the text string that will be shown in COHRA.


--- Parameter #5 is the object ID in hexadecimal notation, the number you have to find
	in a replay (see section "FINDING THE OBJECT ID YOU NEED" below).


--- Parameter #6 is a flag whether or not this command can use coordinates.
	Used for SPECIALABILITY and UNITCOMMAND.


	
EXAMPLE
============================================================================================
Let's say you want to fix the upgrade "M2HB .50 cal Machine Gun (M4)" in a 2.301 replay,
because I'm stupid and messed up the ID, which should be 0x2e according your research.

Your cohra.dat would look like
	
	6,0,UPGRADE,"M2HB .50 cal Machine Gun (M4)",0x2e,0

That's all, an upgrade with ID 0x2e in a 2.301 replay will now show up with the above text.


The Options > Export ID data function in COHRA will export all IDs currently loaded in COHRA
so you can more easily see what needs fixing or adding.



FINDING THE OBJECT ID YOU NEED
============================================================================================
Now the tricky part, although I've made it a bit less tricky for you. I programmed a little tool
for my own use that helped me easily recognize IDs from replay files. It's called COHRA Helper
and I've made it available on my website at http://www.dyxtra.com/coh

What it does is strip out only player commands from a replay file and show the ID you need.
It's not very user friendly since it was not intended for public release, but it works.

Here is an example of a player command as COHRA Helper shows it:

	2F 00 56 00 E8 03 07 00 00 00 03 E8 13 21 E1 05 00 00 00 00 87 42 FF E3 99 --- 0x5e1
	
Right at the end is the object ID, 0x5e1, which you can copy/paste like that into your ID list.

Please note that COHRA Helper shows an object ID for all commands, even when a command doesn't
have (a sensible) one, like move or retreat.

To easily find a certain object ID, start a skirmish game against the AI, perform the command
(use a trainer if you need resources/points to get there, like calling for a Tiger), exit & save
the replay then check it with COHRA Helper.



WARNING
============================================================================================
The parsing of cohra.dat was put together rather hastily, stick to the exact format as the examples
because it's not very flexible and I don't do a lot of error checking. You have been warned :)

